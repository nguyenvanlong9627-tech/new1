# CAR AUTO AI ADAS V3

## Kiến trúc AI
- YOLOP ONNX 640x640: lane-line segmentation + drivable-area segmentation.
- Depth Anything V2 Small ONNX: relative depth.
- ONNX Runtime Web: ưu tiên WebGPU khi `navigator.gpu` có; fallback WASM.
- COCO-SSD: object detector hiện tại.
- ByteTrack JS: association hai tầng high-score / low-score, track lifecycle.
- Không nhận diện `motorcycle`.
- Xe ngược chiều bị lọc khỏi ADAS logic khi motion evidence đủ mạnh.
- No-Scan Zone loại detection trước tracking.

## Model files
Project ưu tiên model local:
- `models/yolop-640-640.onnx`
- `models/depth-anything-v2-small-q4f16.onnx`

Nếu file local không tồn tại, browser thử URL remote được cấu hình trong `ai-engine.js`.

**Lưu ý:** môi trường tạo artifact hiện tại không tải được binary model từ Internet, vì vậy ZIP không nhúng hai file ONNX. Để chạy ổn định/offline, đặt hai model vào thư mục `models/`.

## Chạy
```bash
python -m http.server 8080
```
Mở `http://localhost:8080`.

## Test
```bash
node --check core.js
node --check bytetrack.js
node --check ai-engine.js
node --check app.js
node tests/core.test.js
node tests/v3.test.js
```

Depth Anything V2 trong bản này là **relative depth**, không phải khoảng cách mét trực tiếp. Khoảng cách trên HUD vẫn ghi `EST.`.


# V4 additions
- Traffic Light AI:
  - COCO traffic-light detection.
  - Crop color analysis for RED / YELLOW / GREEN confidence.
- Traffic Sign AI:
  - STOP sign via COCO immediately.
  - Optional `models/traffic-sign-vn.onnx` adapter prepared for a dedicated Vietnamese sign model.
  - The exact decoder is intentionally not faked before a concrete model export is chosen.
- Lane Center:
  - Extracted from drivable/lane segmentation mask; rendered as centerline.
  - Lateral offset shown on HUD.
- Depth temporal smoothing:
  - Median window + bounded EMA per tracked object.
- Vietnam benchmark:
  - Built-in Benchmark toggle + JSON export.
  - `benchmark-vietnam.html` defines scenario groups and metrics.
  - No fake benchmark numbers are included without real videos.

## V4 tests
```bash
node --check lane-center.js
node --check depth-temporal.js
node --check traffic-ai.js
node --check benchmark.js
node --check app.js
node tests/v4.test.js
```


# V4.1 Auto-Benchmark / Auto-Tune
Auto Tune performs controlled trials on the currently loaded video and changes:
- object detection confidence threshold
- object detector stride
- road segmentation stride
- depth stride
- lane-center extraction row step
- minimum lane/drivable width used for center extraction
- depth temporal EMA alpha
- depth temporal median window

Score rewards:
- valid lane coverage
- valid drivable-area coverage
- stable lane center
- stable relative depth

Score penalizes:
- P90 inference latency beyond budget
- unstable object count
- warning without a lead-object hint

**Safety rule:** after all candidates finish, the candidate is applied only if its score beats the baseline by the configured minimum improvement (0.005 score in the browser build). Otherwise baseline is restored.

No benchmark accuracy numbers are fabricated when no real road video is available.
