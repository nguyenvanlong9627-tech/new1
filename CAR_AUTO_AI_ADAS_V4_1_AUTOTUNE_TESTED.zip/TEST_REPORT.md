# TEST REPORT — CAR AUTO AI ADAS V2

## PASS
- `node --check core.js`
- `node --check app.js`
- 23/23 core unit tests
- Static HTML/JS integration: all referenced DOM IDs exist
- Required local files exist: styles.css, core.js, app.js
- No `Math.random` fake telemetry in app.js
- Estimated distance/TTC explicitly labeled EST.

## Browser smoke-test limitation in this container
Chromium headless was attempted against a localhost HTTP server, but the container's Chromium process failed to emit DOM and logged Linux DBus/zygote environment errors. This is recorded as NOT VERIFIED, not as a pass.

## What still requires real-road/video validation
- Lane confidence/tuning under Vietnamese road markings
- Monocular distance calibration for the actual camera height/FOV/pitch
- False-positive rate for collision/lane-departure/cut-in alerts
- Real FPS on the target phone/Android head unit/laptop
- COCO-SSD CDN/model loading on the final deployment network

This prototype is for research/visualization, not vehicle control.
