# TEST REPORT — CAR AUTO AI ADAS V2.1 FILTERED

## Kết quả
- `node --check core.js`: PASS
- `node --check app.js`: PASS
- Core regression tests: 23/23 PASS
- Filtering tests: 6/6 PASS
- DOM ID integrity: PASS
- Motorcycle exclusion from detector allow-list: PASS
- No-Scan pre-tracking filter present: PASS
- Oncoming-motion filter present: PASS

## Thay đổi được kiểm tra
1. Motorcycle không còn nằm trong danh sách class được nhận diện.
2. No-Scan Zone được chuẩn hóa theo tọa độ 0–1 và lọc detection trước tracking.
3. Bộ lọc xe ngược chiều dùng lịch sử nhiều frame: box-growth + chuyển động xuống khung hình + divergence khỏi vanishing point + nằm ngoài ego lane.
4. Xe bị lọc không tham gia lead selection, TTC hoặc cảnh báo va chạm.

## Hạn chế
- Oncoming detection hiện là heuristic từ bounding-box motion, chưa phải model heading/orientation chuyên dụng. Vì vậy được đặt bảo thủ để giảm xóa nhầm xe cùng chiều.
- Browser camera/video end-to-end cần test trên thiết bị thật vì container hiện không cung cấp camera/GPU/browser ổn định.
