# TEST REPORT — CAR AUTO AI ADAS V3

## Kết quả PASS
- `node --check core.js`
- `node --check bytetrack.js`
- `node --check ai-engine.js`
- `node --check app.js`
- 23/23 core regression tests PASS
- Filtering regression tests PASS
- V3 ByteTrack/AI utility tests PASS
- 43/43 JavaScript DOM references tồn tại trong HTML
- Static feature checks PASS:
  - YOLOP Lane AI wiring
  - Drivable Area wiring
  - Depth Anything V2 wiring
  - ByteTrack wiring
  - No-Scan Zone retained
  - Oncoming filter retained
  - `motorcycle` không nằm trong allow-list
- Local HTTP smoke test PASS (`index.html` trả HTTP 200)

## Lỗi đã phát hiện và sửa trong vòng test
- `app.js` có một dấu `}` thừa ở cuối hàm debug.
- Lỗi đã được sửa trước khi đóng gói.
- Toàn bộ test được chạy lại sau khi sửa và đều PASS.

## Chưa thể xác minh trong môi trường hiện tại
- Inference thực của `yolop-640-640.onnx`
- Inference thực của `depth-anything-v2-small-q4f16.onnx`
- Benchmark FPS/latency WebGPU trên Chrome/Edge thật

Lý do: môi trường tạo artifact không thể tải binary model từ Internet và không có trình duyệt WebGPU thực để benchmark.

Vì vậy các mục trên KHÔNG được đánh dấu PASS.

## Cách app xử lý
- Ưu tiên model local trong thư mục `models/`.
- Nếu không có model local, thử URL remote.
- Nếu model không tải được: trạng thái AI chuyển OFFLINE/ERROR, không tạo segmentation/depth giả.
- ONNX Runtime Web ưu tiên WebGPU khi `navigator.gpu` tồn tại và fallback WASM.
- Depth Anything V2 chỉ được dùng như relative depth; không giả định output là mét.

## Model cần đặt local để test/triển khai ổn định
- `models/yolop-640-640.onnx`
- `models/depth-anything-v2-small-q4f16.onnx`
