# TEST REPORT — CAR AUTO AI ADAS V4

## Phương án được triển khai
**Phương án B — Balanced browser ADAS**
- YOLOP ONNX: lane + drivable-area segmentation.
- Lane center extraction từ segmentation mask.
- Depth Anything V2 relative depth + temporal smoothing theo track.
- ByteTrack two-stage association.
- Traffic light detection bằng COCO + phân tích màu đỏ/vàng/xanh.
- STOP sign hoạt động qua COCO.
- Adapter ONNX dành cho model biển báo Việt Nam: `models/traffic-sign-vn.onnx`.
- Benchmark runner cho video giao thông Việt Nam + JSON export.
- WebGPU ưu tiên, WASM fallback.
- Không nhận diện motorcycle.
- Lọc oncoming vehicle.
- No-Scan Zone trước tracking.

## PASS
- 23/23 core regression tests.
- Filtering regression tests PASS.
- V3 ByteTrack/AI utility tests PASS.
- V4 lane/depth/traffic/benchmark tests PASS.
- Syntax PASS:
  - core.js
  - bytetrack.js
  - ai-engine.js
  - lane-center.js
  - depth-temporal.js
  - traffic-ai.js
  - benchmark.js
  - app.js
- 48/48 DOM references hợp lệ.
- `motorcycle` không nằm trong detection allow-list.
- Static integration checks PASS.
- Local HTTP smoke test: `index.html` -> HTTP 200.

## Những gì chưa được đánh dấu PASS
1. YOLOP inference thực — cần file model ONNX.
2. Depth Anything V2 inference thực — cần file model ONNX.
3. Dedicated Vietnamese traffic-sign ONNX inference — cần chọn/đưa model export cụ thể.
4. Benchmark FPS/latency/accuracy trên video Việt Nam thực — cần video input thực tế.

Không có số liệu giả cho các mục trên.

## Traffic Sign
STOP sign hoạt động ngay bằng COCO-SSD.
Module `OptionalTrafficSignONNX` đã chuẩn bị đường cắm `models/traffic-sign-vn.onnx`.
Decoder output không bị giả định vì mỗi model YOLO/custom export có tensor layout khác nhau. Khi có model Việt Nam cụ thể, cần map decoder đúng theo model đó.

## Vietnam benchmark scenarios
- VN_CITY_DAY
- VN_CITY_NIGHT
- VN_RAIN
- VN_HIGHWAY
- VN_FADED_LANES
- VN_INTERSECTION
- VN_SIGNS
- VN_DENSE_TRAFFIC

## Metrics
- Lane valid %
- Drivable-area valid %
- Object inference ms
- Road inference ms
- Depth inference ms
- Traffic-light detections
- Traffic-sign detections
- Warning-frame %
- Average tracked objects/frame
