# TEST REPORT — CAR AUTO AI ADAS V4.1 AUTO-TUNE

## Mục tiêu vòng này
`benchmark → phát hiện lỗi → chỉnh threshold/model stride/lane center/depth smoothing → benchmark lại → chỉ giữ cấu hình tốt hơn`

## Auto-Tune đang thử tự động
- Object confidence threshold
- Object detector stride
- Road/Lane segmentation stride
- Depth inference stride
- Lane-center extraction step
- Lane-center minimum width
- Depth temporal EMA alpha
- Depth temporal median window

## Hàm chấm điểm
Thưởng:
- lane coverage hợp lệ
- drivable-area coverage hợp lệ
- lane center ổn định
- relative depth ổn định

Phạt:
- P90 inference latency vượt budget
- số object dao động bất thường
- warning nhưng không có lead object tương ứng

## Quy tắc chọn
- Baseline luôn là candidate đầu tiên.
- Chỉ áp dụng candidate mới nếu score tốt hơn baseline ít nhất **0.005**.
- Nếu không đạt: tự phục hồi baseline.

## Kết quả test
- 23/23 core regression tests: PASS
- V3 ByteTrack/AI utility: PASS
- V4 lane/depth/traffic/benchmark: PASS
- V4.1 AutoTune tests: PASS
- Syntax check toàn bộ JS chính: PASS
- DOM references: 50/50 hợp lệ
- Missing DOM refs: none

## Lỗi tìm thấy trong quá trình test
Bản AutoTune đầu tiên dùng minimum-improvement quá cao so với thang điểm hiện tại.
Test đã bắt trường hợp candidate tốt hơn nhưng không được chọn.
Đã hiệu chỉnh threshold chọn cấu hình từ 0.025 xuống 0.005 và chạy lại toàn bộ regression suite: PASS.

## Benchmark video Việt Nam thực
Chưa chạy được vì không tìm thấy video dashcam/giao thông phù hợp trong file hiện có.
Không tạo số liệu benchmark giả.

Khi người dùng nạp một video thực:
1. Mở video trong app.
2. Bấm `🧠 Auto Tune`.
3. Hệ thống chạy baseline + các candidate.
4. Mỗi candidate lấy 90 frame đo.
5. Tự chọn candidate tốt hơn hoặc phục hồi baseline.
6. Có thể bật `📊 Benchmark` để xuất báo cáo JSON.

## Những phần vẫn cần model binary
- YOLOP ONNX
- Depth Anything V2 ONNX
- Vietnamese traffic-sign ONNX nếu muốn nhận nhiều biển hơn STOP

Không có model -> module báo OFFLINE/ERROR, không tạo output giả.
