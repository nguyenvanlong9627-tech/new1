(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.ADASEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const MODEL_URLS={
  yolopLocal:'models/yolop-640-640.onnx',
  yolopRemote:'https://github.com/hustvl/YOLOP/raw/main/weights/yolop-640-640.onnx',
  depthLocal:'models/depth-anything-v2-small-q4f16.onnx',
  depthRemote:'https://cdn.glitch.global/0f5359e2-6022-421b-88f7-13e276d0fb33/model_q4f16.onnx'
};
function hasWebGPU(){return typeof navigator!=='undefined'&&!!navigator.gpu}
async function createSession(urls,{preferWebGPU=true}={}){
  if(typeof ort==='undefined')throw new Error('ONNX Runtime Web chưa tải');
  const providers=preferWebGPU&&hasWebGPU()?['webgpu','wasm']:['wasm'];
  let lastErr=null;
  for(const url of urls){
    try{
      try{
        const session=await ort.InferenceSession.create(url,{executionProviders:providers,graphOptimizationLevel:'all'});
        return {session,url,provider:providers[0]};
      }catch(e){
        lastErr=e;
        if(providers[0]==='webgpu'){
          const session=await ort.InferenceSession.create(url,{executionProviders:['wasm'],graphOptimizationLevel:'all'});
          return {session,url,provider:'wasm'};
        }
      }
    }catch(e){lastErr=e}
  }
  throw lastErr||new Error('Không tạo được ONNX session');
}
function makeCanvas(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return c}
function imageDataFromVideo(video,w,h){
  const c=makeCanvas(w,h),ctx=c.getContext('2d',{willReadFrequently:true});
  ctx.drawImage(video,0,0,w,h);return ctx.getImageData(0,0,w,h);
}
function nchwFromImageData(img,{mean=[0,0,0],std=[1,1,1],scale=1/255}={}){
  const {data,width,height}=img,n=width*height,out=new Float32Array(n*3);
  for(let i=0;i<n;i++){const j=i*4;out[i]=(data[j]*scale-mean[0])/std[0];out[n+i]=(data[j+1]*scale-mean[1])/std[1];out[n*2+i]=(data[j+2]*scale-mean[2])/std[2]}
  return out;
}
class RoadSegmentationEngine{
  constructor(){this.session=null;this.provider='—';this.last=null;this.loading=false}
  async init(){
    if(this.session||this.loading)return;this.loading=true;
    try{const r=await createSession([MODEL_URLS.yolopLocal,MODEL_URLS.yolopRemote]);this.session=r.session;this.provider=r.provider;return r}
    finally{this.loading=false}
  }
  async infer(video){
    if(!this.session)throw new Error('YOLOP session chưa sẵn sàng');
    const img=imageDataFromVideo(video,640,640),input=nchwFromImageData(img,{mean:[0.485,0.456,0.406],std:[0.229,0.224,0.225]});
    const name=this.session.inputNames[0],t0=performance.now();
    const outputs=await this.session.run({[name]:new ort.Tensor('float32',input,[1,3,640,640])});
    const ms=performance.now()-t0,names=this.session.outputNames;
    const segs=names.map(n=>outputs[n]).filter(x=>x.dims?.length===4&&x.dims[1]===2);
    const drive=segs[0]||null,lane=segs[1]||null;
    if(!drive||!lane)throw new Error('Không tìm thấy 2 segmentation heads từ YOLOP');
    this.last={drive,lane,ms};return this.last;
  }
}
class DepthEngine{
  constructor(){this.session=null;this.provider='—';this.last=null;this.loading=false}
  async init(){
    if(this.session||this.loading)return;this.loading=true;
    try{const r=await createSession([MODEL_URLS.depthLocal,MODEL_URLS.depthRemote]);this.session=r.session;this.provider=r.provider;return r}
    finally{this.loading=false}
  }
  async infer(video){
    if(!this.session)throw new Error('Depth session chưa sẵn sàng');
    const size=518,img=imageDataFromVideo(video,size,size),input=nchwFromImageData(img,{mean:[0.485,0.456,0.406],std:[0.229,0.224,0.225]});
    const name=this.session.inputNames[0],t0=performance.now();
    const outputs=await this.session.run({[name]:new ort.Tensor('float32',input,[1,3,size,size])});
    const ms=performance.now()-t0,out=outputs[this.session.outputNames[0]];
    this.last={tensor:out,ms,size};return this.last;
  }
}
function binaryMaskFrom2Channel(tensor,threshold=0){
  const [b,c,h,w]=tensor.dims,d=tensor.data,n=h*w,out=new Uint8Array(n);
  for(let i=0;i<n;i++)out[i]=(d[n+i]-d[i])>threshold?1:0;
  return {data:out,width:w,height:h};
}
function maskStats(mask){let sum=0;for(const v of mask.data)sum+=v;return {ratio:sum/mask.data.length}}
function renderMask(mask,canvas,{fill='rgba(0,255,130,.30)'}={}){
  const tmp=makeCanvas(mask.width,mask.height),tctx=tmp.getContext('2d'),img=tctx.createImageData(mask.width,mask.height);
  const m=fill.match(/rgba?\(([^)]+)\)/),parts=m?m[1].split(',').map(x=>parseFloat(x.trim())):[0,255,130,.3],[r,g,b,a=1]=parts;
  for(let i=0;i<mask.data.length;i++){const j=i*4,v=mask.data[i];img.data[j]=r;img.data[j+1]=g;img.data[j+2]=b;img.data[j+3]=v?Math.round(a*255):0}
  tctx.putImageData(img,0,0);const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);ctx.imageSmoothingEnabled=true;ctx.drawImage(tmp,0,0,canvas.width,canvas.height);
}
function normalizeDepthTensor(tensor){
  const d=tensor.data;let min=Infinity,max=-Infinity;
  for(let i=0;i<d.length;i++){const v=d[i];if(v<min)min=v;if(v>max)max=v}
  const span=Math.max(1e-9,max-min),out=new Float32Array(d.length);
  for(let i=0;i<d.length;i++)out[i]=(d[i]-min)/span;
  const dims=tensor.dims,h=dims[dims.length-2],w=dims[dims.length-1];
  return {data:out,width:w,height:h,min,max};
}
function renderDepth(depth,canvas){
  const tmp=makeCanvas(depth.width,depth.height),ctx=tmp.getContext('2d'),img=ctx.createImageData(depth.width,depth.height);
  for(let i=0;i<depth.data.length;i++){const v=Math.max(0,Math.min(1,depth.data[i])),j=i*4;img.data[j]=Math.round(255*v);img.data[j+1]=Math.round(255*(1-Math.abs(v-.5)*2));img.data[j+2]=Math.round(255*(1-v));img.data[j+3]=190}
  ctx.putImageData(img,0,0);const o=canvas.getContext('2d');o.clearRect(0,0,canvas.width,canvas.height);o.drawImage(tmp,0,0,canvas.width,canvas.height);
}
function sampleDepth(depth,nx,ny){
  if(!depth)return null;const x=Math.max(0,Math.min(depth.width-1,Math.round(nx*(depth.width-1)))),y=Math.max(0,Math.min(depth.height-1,Math.round(ny*(depth.height-1))));
  return depth.data[y*depth.width+x];
}
function sampleMask(mask,nx,ny){
  if(!mask)return false;const x=Math.max(0,Math.min(mask.width-1,Math.round(nx*(mask.width-1)))),y=Math.max(0,Math.min(mask.height-1,Math.round(ny*(mask.height-1))));
  return !!mask.data[y*mask.width+x];
}
return {MODEL_URLS,hasWebGPU,createSession,RoadSegmentationEngine,DepthEngine,binaryMaskFrom2Channel,maskStats,renderMask,normalizeDepthTensor,renderDepth,sampleDepth,sampleMask};
});