(() => {
'use strict';
const C=ADASCore,$=id=>document.getElementById(id);
const video=$('video'),overlay=$('overlay'),ctx=overlay.getContext('2d',{alpha:true});
const segCanvas=$('segmentationCanvas'),depthCanvas=$('depthCanvas');
let model=null,running=false,debug=false,depthVisible=false,frame=0,lastTs=performance.now(),fpsEMA=0,objInferenceMs=0;
let detections=[],tracks=[],gpsWatch=null,noScanMode=false,noScanZones=[],dragStart=null,dragPreview=null;
let roadMask=null,laneMask=null,depthMap=null,roadMs=0,depthMs=0,roadBusy=false,depthBusy=false;
const events=[],history=new Map(),motionHistory=new Map();
const depthSmoother=new DepthTemporalAI.TemporalDepthSmoother({alpha:.32,medianWindow:5,maxJump:.22});
let benchmark=null,benchmarkEnabled=false,lastTrafficLight=null,lastTrafficSigns=[];
let autoTuner=null,autoTuneEnabled=false,tuneResult=null;
let runtimeConfig={objectThreshold:.18,detectEvery:4,roadEvery:5,depthEvery:12,laneStep:8,laneMinWidth:.08,depthAlpha:.32,depthWindow:5};
const allowed=new Set(['car','truck','bus','bicycle','person','traffic light','stop sign']);
const heights={person:1.70,bicycle:1.25,car:1.50,truck:3.2,bus:3.2};
const tracker=new ByteTrackJS.ByteTracker({highThreshold:.5,lowThreshold:.12,matchThreshold:.28,lowMatchThreshold:.18,maxLost:18,minHits:2});
const roadEngine=new ADASEngine.RoadSegmentationEngine(),depthEngine=new ADASEngine.DepthEngine();

function emit(type,data={}){events.push({time:new Date().toISOString(),type,...data});if(events.length>2000)events.shift()}
function state(id,text,cls=''){$(id).textContent=text;$(id).className=cls}
async function loadObjectAI(){try{if(typeof cocoSsd==='undefined')throw new Error('COCO-SSD unavailable');model=await cocoSsd.load({base:'lite_mobilenet_v2'});state('aiState','READY','ok');emit('object_ai_ready')}catch(e){state('aiState','OFFLINE','danger');emit('object_ai_error',{message:e.message})}}
async function loadRoadAI(){try{state('roadAIState','LOADING');const r=await roadEngine.init();state('roadAIState','READY','ok');$('epHud').textContent=r.provider.toUpperCase();emit('road_ai_ready',{provider:r.provider,url:r.url})}catch(e){state('roadAIState','OFFLINE','danger');emit('road_ai_error',{message:e.message})}}
async function loadDepthAI(){try{state('depthAIState','LOADING');const r=await depthEngine.init();state('depthAIState','READY','ok');$('epHud').textContent=r.provider.toUpperCase();emit('depth_ai_ready',{provider:r.provider,url:r.url})}catch(e){state('depthAIState','OFFLINE','danger');emit('depth_ai_error',{message:e.message})}}
loadObjectAI();loadRoadAI();loadDepthAI();
const signEngine=new TrafficAI.OptionalTrafficSignONNX(); signEngine.init().then(()=>emit('traffic_sign_ai_ready',{provider:signEngine.provider})).catch(e=>emit('traffic_sign_ai_optional_offline',{message:e.message}));

function resize(){const r=overlay.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);for(const c of [overlay,segCanvas,depthCanvas]){c.width=Math.round(r.width*dpr);c.height=Math.round(r.height*dpr);c.style.width=r.width+'px';c.style.height=r.height+'px'}ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener('resize',resize);

$('cameraBtn').onclick=async()=>{try{if(video.srcObject)video.srcObject.getTracks().forEach(t=>t.stop());video.srcObject=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1280},height:{ideal:720}},audio:false});video.removeAttribute('src');await video.play();start();emit('camera_started')}catch(e){alert('Không mở được camera: '+e.message);emit('camera_error',{message:e.message})}};
$('fileInput').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;if(video.srcObject)video.srcObject.getTracks().forEach(t=>t.stop());video.srcObject=null;video.src=URL.createObjectURL(f);video.loop=true;await video.play();start();emit('video_loaded',{name:f.name,size:f.size})};
$('debugBtn').onclick=()=>{debug=!debug;$('debugBtn').textContent=debug?'🛠 Debug ON':'🛠 Debug'};
$('depthBtn').onclick=()=>{depthVisible=!depthVisible;depthCanvas.style.display=depthVisible?'block':'none';$('depthBtn').textContent=depthVisible?'🌊 Depth ON':'🌊 Depth'};
$('noScanBtn').onclick=()=>{noScanMode=!noScanMode;$('stage').classList.toggle('no-scan-edit',noScanMode);$('noScanBtn').textContent=noScanMode?'🚫 Đang vẽ vùng':'🚫 Vùng không quét';emit('no_scan_mode',{enabled:noScanMode})};
$('clearNoScanBtn').onclick=()=>{noScanZones=[];dragPreview=null;emit('no_scan_cleared')};


$('autoTuneBtn').onclick=()=>{
 if(autoTuneEnabled){
   autoTuneEnabled=false;$('autoTuneBtn').textContent='🧠 Auto Tune';emit('autotune_cancelled');return;
 }
 const base=currentBaseConfig();
 autoTuner=new ADASAutoTune.AutoTuner({baseConfig:base,trialFrames:90,minImprovement:.005,latencyBudgetMs:130});
 const first=autoTuner.start();applyTuneConfig(first);
 autoTuneEnabled=true;tuneResult=null;$('autoTuneBtn').textContent='🧠 Tuning…';$('tuneScore').textContent='RUN';
 emit('autotune_started',{base,candidates:autoTuner.candidates.length});
};

$('benchmarkBtn').onclick=()=>{
 benchmarkEnabled=!benchmarkEnabled;
 if(benchmarkEnabled){
   benchmark=new ADASBenchmark.BenchmarkSession({profile:'Vietnam-road-video',appVersion:'4.0',notes:'Use user-supplied or licensed Vietnam road videos'});
   $('benchmarkBtn').textContent='📊 Benchmark ON';
   emit('benchmark_started');
 }else{
   $('benchmarkBtn').textContent='📊 Benchmark';
   emit('benchmark_stopped',{summary:benchmark?.summary?.()||null});
 }
};
$('benchmarkExportBtn').onclick=()=>{
 const payload=benchmark?.summary?.()||{message:'Benchmark chưa chạy'};
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='adas-vietnam-benchmark.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

$('exportBtn').onclick=()=>{const blob=new Blob([JSON.stringify({version:'3.0',exportedAt:new Date().toISOString(),events},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='adas-v3-events.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};

function canvasPoint(e){const r=overlay.getBoundingClientRect();return {x:C.clamp((e.clientX-r.left)/r.width,0,1),y:C.clamp((e.clientY-r.top)/r.height,0,1)}}
overlay.addEventListener('pointerdown',e=>{if(!noScanMode)return;dragStart=canvasPoint(e);dragPreview=null;overlay.setPointerCapture(e.pointerId)});
overlay.addEventListener('pointermove',e=>{if(!noScanMode||!dragStart)return;const p=canvasPoint(e);dragPreview={x:Math.min(dragStart.x,p.x),y:Math.min(dragStart.y,p.y),w:Math.abs(p.x-dragStart.x),h:Math.abs(p.y-dragStart.y)}});
overlay.addEventListener('pointerup',e=>{if(!noScanMode||!dragStart)return;const p=canvasPoint(e),z={x:Math.min(dragStart.x,p.x),y:Math.min(dragStart.y,p.y),w:Math.abs(p.x-dragStart.x),h:Math.abs(p.y-dragStart.y)};if(z.w>.015&&z.h>.015){noScanZones.push(z);emit('no_scan_added',z)}dragStart=null;dragPreview=null});

$('gpsBtn').onclick=()=>{if(!navigator.geolocation)return alert('Không hỗ trợ GPS');if(gpsWatch!==null){navigator.geolocation.clearWatch(gpsWatch);gpsWatch=null;$('gpsBtn').textContent='📍 GPS';$('speedSource').textContent='MANUAL';return}gpsWatch=navigator.geolocation.watchPosition(p=>{if(Number.isFinite(p.coords.speed)&&p.coords.speed>=0){$('speed').value=C.clamp(p.coords.speed*3.6,0,160);$('speedSource').textContent='GPS';updateControls()}},e=>emit('gps_error',{message:e.message}),{enableHighAccuracy:true,maximumAge:500});$('gpsBtn').textContent='📍 GPS ON'};
['speed','fov','camHeight','horizon','detectEvery','roadEvery','depthEvery'].forEach(id=>$(id).oninput=updateControls);
function updateControls(){
 if(!autoTuneEnabled){
   runtimeConfig.detectEvery=+$('detectEvery').value;
   runtimeConfig.roadEvery=+$('roadEvery').value;
   runtimeConfig.depthEvery=+$('depthEvery').value;
 }$('speedVal').textContent=`${Math.round(+$('speed').value)} km/h`;$('speedHud').textContent=Math.round(+$('speed').value);$('fovVal').textContent=`${$('fov').value}°`;$('camHeightVal').textContent=`${(+$('camHeight').value/100).toFixed(2)} m`;$('horizonVal').textContent=`${$('horizon').value}%`;$('detectEveryVal').textContent=`${$('detectEvery').value} frame`;$('roadEveryVal').textContent=`${$('roadEvery').value} frame`;$('depthEveryVal').textContent=`${$('depthEvery').value} frame`}
updateControls();


function currentBaseConfig(){
 return {
   objectThreshold:runtimeConfig.objectThreshold,
   detectEvery:+$('detectEvery').value,
   roadEvery:+$('roadEvery').value,
   depthEvery:+$('depthEvery').value,
   laneStep:runtimeConfig.laneStep,
   laneMinWidth:runtimeConfig.laneMinWidth,
   depthAlpha:runtimeConfig.depthAlpha,
   depthWindow:runtimeConfig.depthWindow
 };
}
function applyTuneConfig(c){
 runtimeConfig={...runtimeConfig,...c};
 $('detectEvery').value=c.detectEvery;$('roadEvery').value=c.roadEvery;$('depthEvery').value=c.depthEvery;
 depthSmoother.alpha=c.depthAlpha;depthSmoother.medianWindow=c.depthWindow;
 updateControls();
 emit('autotune_config_applied',c);
}

function start(){if(running)return;running=true;resize();requestAnimationFrame(loop)}
async function loop(ts){
 if(!running)return;
 const dt=Math.max(1,ts-lastTs);lastTs=ts;const fps=1000/dt;fpsEMA=fpsEMA?C.lerp(fpsEMA,fps,.08):fps;$('fpsHud').textContent=fpsEMA.toFixed(0);
 if(video.readyState>=2){
  frame++;const W=overlay.clientWidth,H=overlay.clientHeight;ctx.clearRect(0,0,W,H);
  if(roadEngine.session&&!roadBusy&&frame%runtimeConfig.roadEvery===0){roadBusy=true;roadEngine.infer(video).then(r=>{roadMs=r.ms;roadMask=ADASEngine.binaryMaskFrom2Channel(r.drive);laneMask=ADASEngine.binaryMaskFrom2Channel(r.lane);renderRoadMasks()}).catch(e=>{state('roadAIState','ERROR','danger');emit('road_inference_error',{message:e.message})}).finally(()=>roadBusy=false)}
  if(depthEngine.session&&!depthBusy&&frame%runtimeConfig.depthEvery===0){depthBusy=true;depthEngine.infer(video).then(r=>{depthMs=r.ms;depthMap=ADASEngine.normalizeDepthTensor(r.tensor);if(depthVisible)ADASEngine.renderDepth(depthMap,depthCanvas)}).catch(e=>{state('depthAIState','ERROR','danger');emit('depth_inference_error',{message:e.message})}).finally(()=>depthBusy=false)}
  if(model&&frame%runtimeConfig.detectEvery===0){const t0=performance.now();try{const raw=await model.detect(video,40,runtimeConfig.objectThreshold);objInferenceMs=performance.now()-t0;
      const filtered=raw.filter(x=>allowed.has(x.class)).filter(x=>!inNoScanBBox(x.bbox,W,H));
      const trafficBase=TrafficAI.filterBaseTrafficDetections(filtered);
      const tl=trafficBase.find(x=>x.class==='traffic light');
      lastTrafficLight=tl?{...tl,...TrafficAI.classifyTrafficLightColor(video,tl.bbox)}:null;
      lastTrafficSigns=trafficBase.filter(x=>x.class==='stop sign').map(x=>({type:'STOP',score:x.score,bbox:x.bbox}));
      detections=filtered.filter(x=>x.class!=='traffic light'&&x.class!=='stop sign');
      tracks=tracker.update(detections)}catch(e){emit('object_inference_error',{message:e.message})}}else if(detections.length){tracks=tracker.update([])}
  const world=fuseWorld(tracks,W,H,dt/1000);
  drawLaneCenterline(world,W,H);drawObjects(world.objects);drawNoScanZones(W,H);updateHUD(world);drawDebug(world,W,H);
  if(benchmarkEnabled&&benchmark){
    const laneStats=laneMask?ADASEngine.maskStats(laneMask):{ratio:0},roadStats=roadMask?ADASEngine.maskStats(roadMask):{ratio:0};
    benchmark.addFrame({objectMs:objInferenceMs,roadMs,depthMs,objects:world.objects.length,warning:!!world.risk.text,
      laneConfidence:world.centerline?.confidence||0,roadConfidence:Math.min(1,roadStats.ratio*4),
      trafficLights:world.trafficLight?1:0,trafficSigns:world.trafficSigns?.length||0});
  }
  if(autoTuneEnabled&&autoTuner){
    const roadStats=roadMask?ADASEngine.maskStats(roadMask):{ratio:0};
    const leadDepth=world.lead?.relativeDepth;
    const res=autoTuner.addFrame({
      objectMs:objInferenceMs,roadMs,depthMs,objects:world.objects.length,warning:!!world.risk.text,
      laneConfidence:world.centerline?.confidence||0,roadConfidence:Math.min(1,roadStats.ratio*4),
      laneOffset:world.laneOffset?.offset,depth:leadDepth,
      falseRiskHint:!!world.risk.text && !world.lead
    });
    if(res.switchConfig){applyTuneConfig(res.config);$('tuneScore').textContent=`${autoTuner.index+1}/${autoTuner.candidates.length}`;}
    if(res.done){
      tuneResult=res;autoTuneEnabled=false;applyTuneConfig(res.selected);
      $('autoTuneBtn').textContent='🧠 Auto Tune';
      $('tuneScore').textContent=res.improved?`${res.best.score.toFixed(3)} ↑`:`${res.base.score.toFixed(3)} KEEP`;
      emit('autotune_finished',{improved:res.improved,baseScore:res.base.score,bestScore:res.best.score,selected:res.selected,results:res.results});
    }
  }
 }
 requestAnimationFrame(loop);
}

function renderRoadMasks(){
 if(!roadMask||!laneMask)return;
 const c=segCanvas,off=document.createElement('canvas');off.width=c.width;off.height=c.height;ADASEngine.renderMask(roadMask,off,{fill:'rgba(0,210,120,.18)'});
 const ctx2=c.getContext('2d');ctx2.clearRect(0,0,c.width,c.height);ctx2.drawImage(off,0,0);
 const laneLayer=document.createElement('canvas');laneLayer.width=c.width;laneLayer.height=c.height;ADASEngine.renderMask(laneMask,laneLayer,{fill:'rgba(90,255,220,.78)'});ctx2.drawImage(laneLayer,0,0);
}
function inNoScanBBox(bbox,W,H){const sx=W/(video.videoWidth||W),sy=H/(video.videoHeight||H),cx=(bbox[0]+bbox[2]/2)*sx/W,cy=(bbox[1]+bbox[3]/2)*sy/H;return noScanZones.some(z=>cx>=z.x&&cx<=z.x+z.w&&cy>=z.y&&cy<=z.y+z.h)}
function drawNoScanZones(W,H){ctx.save();ctx.setLineDash([8,6]);ctx.lineWidth=2;ctx.strokeStyle='#ff5b6e';ctx.fillStyle='rgba(255,75,95,.10)';for(const z of [...noScanZones,...(dragPreview?[dragPreview]:[])]){ctx.fillRect(z.x*W,z.y*H,z.w*W,z.h*H);ctx.strokeRect(z.x*W,z.y*H,z.w*W,z.h*H)}ctx.restore()}
function updateMotion(t,box){const now=performance.now(),cx=box[0]+box[2]/2,cy=box[1]+box[3]/2,arr=motionHistory.get(t.id)||[];arr.push({time:now,cx,cy,w:box[2],h:box[3]});while(arr.length>8)arr.shift();motionHistory.set(t.id,arr);return arr}
function isLikelyOncoming(t,box,W,H,inDrive){const arr=updateMotion(t,box);if(arr.length<5)return false;const a=arr[0],b=arr[arr.length-1],sec=Math.max(.08,(b.time-a.time)/1000),grow=(b.h-a.h)/Math.max(8,a.h)/sec,down=(b.cy-a.cy)/H/sec,centerDist=Math.abs((b.cx/W)-.5);return !inDrive&&centerDist>.12&&grow>.18&&down>.018}
function geometricDistance(t,box,W,H){const fov=+$('fov').value*Math.PI/180,focal=W/(2*Math.tan(fov/2)),horizonY=H*(+$('horizon').value/100),cameraHeight=+$('camHeight').value/100,objectHeight=heights[t.class]||1.5;return C.distanceFusion({boxHeightPx:box[3],footY:box[1]+box[3],horizonY,focalPx:focal,objectHeight,cameraHeight})}
function fuseWorld(ts,W,H){
 const centerline=laneMask?LaneCenterAI.normalizedCenterline(laneMask,{
   step:runtimeConfig.laneStep,minWidthRatio:runtimeConfig.laneMinWidth
 }):{points:[],confidence:0};
 const laneOffset=LaneCenterAI.lateralOffset(centerline);
 const sx=W/(video.videoWidth||W),sy=H/(video.videoHeight||H),objs=[];
 for(const t of ts){
  const [x,y,w,h]=t.bbox,b=[x*sx,y*sy,w*sx,h*sy],footX=b[0]+b[2]/2,footY=b[1]+b[3],nx=footX/W,ny=footY/H;
  const inDrive=roadMask?ADASEngine.sampleMask(roadMask,nx,ny):(nx>.36&&nx<.64),oncoming=isLikelyOncoming(t,b,W,H,inDrive);
  if(oncoming){emit('oncoming_filtered',{id:t.id,class:t.class});continue}
  const distance=geometricDistance(t,b,W,H),rawDepth=depthMap?ADASEngine.sampleDepth(depthMap,nx,Math.max(0,ny-.05)):null,relDepth=depthSmoother.update(t.id,rawDepth);
  let closing=null,ttc=null;const prev=history.get(t.id),now=performance.now();
  if(prev&&distance){const sec=(now-prev.time)/1000;if(sec>.08){closing=(prev.distance-distance.estimate)/sec;if(closing>.35)ttc=distance.estimate/closing}}
  if(distance)history.set(t.id,{distance:distance.estimate,time:now});
  objs.push({...t,screenBox:b,inDrive,oncoming:false,distance,relativeDepth:relDepth,ttc,closing});
 }
 const cand=objs.filter(o=>o.inDrive&&o.distance);cand.sort((a,b)=>a.distance.estimate-b.distance.estimate);const lead=cand[0]||null;
 const risk=C.riskDecision({lead,laneDeparture:false,cutIn:false,speedKmh:+$('speed').value,laneConfidence:laneMask?.data?0.8:0});
 return {objects:objs,lead,risk,centerline,laneOffset,trafficLight:lastTrafficLight,trafficSigns:lastTrafficSigns};
}

function drawLaneCenterline(world,W,H){
 const pts=world.centerline?.points||[]; if(pts.length<2)return;
 ctx.save();ctx.strokeStyle='#7cf7ff';ctx.lineWidth=3;ctx.setLineDash([7,5]);ctx.beginPath();
 pts.forEach((p,i)=>{const x=p.x*W,y=p.y*H;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});
 ctx.stroke();ctx.restore();
}

function drawObjects(objs){ctx.save();ctx.font='600 12px system-ui';for(const o of objs){const [x,y,w,h]=o.screenBox,danger=o.inDrive&&((o.ttc&&o.ttc<2)||(o.distance&&o.distance.estimate<7));ctx.strokeStyle=danger?'#ff496c':o.inDrive?'#ffd33d':'#33d6ff';ctx.lineWidth=danger?4:2;ctx.strokeRect(x,y,w,h);let txt=`${o.class.toUpperCase()} #${o.id} ${(o.score*100).toFixed(0)}%`;if(o.distance)txt+=` EST ${o.distance.estimate.toFixed(1)}m`;if(o.relativeDepth!=null)txt+=` D:${o.relativeDepth.toFixed(2)}`;const tw=ctx.measureText(txt).width+10;ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(x,Math.max(0,y-20),tw,19);ctx.fillStyle='#fff';ctx.fillText(txt,x+5,Math.max(13,y-6))}ctx.restore()}
function updateHUD(w){
 $('objectCount').textContent=w.objects.length;const laneStats=laneMask?ADASEngine.maskStats(laneMask):null,roadStats=roadMask?ADASEngine.maskStats(roadMask):null;
 $('laneConf').textContent=laneStats?`${Math.round(Math.min(1,laneStats.ratio*12)*100)}%`:'0%';$('drivableConf').textContent=roadStats?`${Math.round(Math.min(1,roadStats.ratio*4)*100)}%`:'0%';
 $('leadDistance').textContent=w.lead?.distance?`${w.lead.distance.estimate.toFixed(1)} m`:'—';$('distanceUncertainty').textContent=w.lead?.distance?`${w.lead.distance.low.toFixed(1)}–${w.lead.distance.high.toFixed(1)} m`:'—';$('relativeDepth').textContent=w.lead?.relativeDepth!=null?w.lead.relativeDepth.toFixed(2):'—';$('ttc').textContent=w.lead?.ttc&&w.lead.ttc<30?`${w.lead.ttc.toFixed(1)} s`:'—';$('roadInference').textContent=roadMs?`${roadMs.toFixed(0)} ms`:'—';$('depthInference').textContent=depthMs?`${depthMs.toFixed(0)} ms`:'—';
 $('laneOffset').textContent=w.laneOffset?`${(w.laneOffset.offset*100).toFixed(1)}%`:'—';
 $('trafficLightState').textContent=w.trafficLight?`${w.trafficLight.state.toUpperCase()} ${(w.trafficLight.confidence*100).toFixed(0)}%`:'—';
 $('trafficSignState').textContent=w.trafficSigns?.length?`STOP ${(w.trafficSigns[0].score*100).toFixed(0)}%`:(signEngine.session?'SIGN AI READY':'—');
 $('warning').textContent=w.risk.text;$('warning').style.color=w.risk.level==='danger'?'#ff496c':w.risk.level==='warn'?'#ffd33d':'transparent';
 const flags=[];if(!roadMask)flags.push('ROAD AI NOT READY');if(!depthMap)flags.push('DEPTH AI NOT READY');if(noScanZones.length)flags.push(`${noScanZones.length} NO-SCAN`);$('sceneFlags').innerHTML=flags.map(x=>`<span>${x}</span>`).join('');
}
function drawDebug(w,W,H){if(!debug){$('debugLog').textContent='';return}const l=w.lead;$('debugLog').textContent=`CAR AUTO AI ADAS V3
Object inference: ${objInferenceMs.toFixed(1)} ms
Road AI: ${roadMs.toFixed(1)} ms (${roadEngine.provider})
Depth AI: ${depthMs.toFixed(1)} ms (${depthEngine.provider})
WebGPU available: ${ADASEngine.hasWebGPU()}
FPS: ${fpsEMA.toFixed(1)}
ByteTrack active: ${tracks.length}
Objects after filters: ${w.objects.length}
No-scan zones: ${noScanZones.length}
Motorcycle class allowed: ${allowed.has('motorcycle')}
Lead: ${l?`${l.class} #${l.id}`:'none'}
Lead distance: ${l?.distance?l.distance.estimate.toFixed(2)+' m EST.':'n/a'}
Lead relative depth: ${l?.relativeDepth!=null?l.relativeDepth.toFixed(3):'n/a'}
TTC: ${l?.ttc?l.ttc.toFixed(2)+' s EST.':'n/a'}
Events: ${events.length}`}
})();