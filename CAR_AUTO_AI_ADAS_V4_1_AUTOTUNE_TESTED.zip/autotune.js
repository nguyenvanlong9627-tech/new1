(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.ADASAutoTune=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

function variance(arr){
  if(!arr.length)return 0;
  const m=arr.reduce((a,b)=>a+b,0)/arr.length;
  return arr.reduce((a,b)=>a+(b-m)*(b-m),0)/arr.length;
}
function avg(arr){return arr.length?arr.reduce((a,b)=>a+b,0)/arr.length:0}
function percentile(arr,p){
  if(!arr.length)return 0;
  const a=[...arr].sort((x,y)=>x-y);
  return a[Math.min(a.length-1,Math.max(0,Math.floor((a.length-1)*p)))];
}

class TrialMetrics{
  constructor(config){
    this.config={...config};this.frames=0;
    this.laneConf=[];this.roadConf=[];this.laneOffset=[];
    this.depth=[];this.objectMs=[];this.roadMs=[];this.depthMs=[];
    this.objectCounts=[];this.warningFrames=0;this.falseRiskHints=0;
  }
  add(m){
    this.frames++;
    if(Number.isFinite(m.laneConfidence))this.laneConf.push(m.laneConfidence);
    if(Number.isFinite(m.roadConfidence))this.roadConf.push(m.roadConfidence);
    if(Number.isFinite(m.laneOffset))this.laneOffset.push(m.laneOffset);
    if(Number.isFinite(m.depth))this.depth.push(m.depth);
    if(Number.isFinite(m.objectMs)&&m.objectMs>0)this.objectMs.push(m.objectMs);
    if(Number.isFinite(m.roadMs)&&m.roadMs>0)this.roadMs.push(m.roadMs);
    if(Number.isFinite(m.depthMs)&&m.depthMs>0)this.depthMs.push(m.depthMs);
    if(Number.isFinite(m.objects))this.objectCounts.push(m.objects);
    if(m.warning)this.warningFrames++;
    if(m.falseRiskHint)this.falseRiskHints++;
  }
  summary(){
    const laneValid=this.laneConf.filter(x=>x>.35).length/Math.max(1,this.frames);
    const roadValid=this.roadConf.filter(x=>x>.35).length/Math.max(1,this.frames);
    const laneJitter=Math.sqrt(variance(this.laneOffset));
    const depthJitter=Math.sqrt(variance(this.depth));
    const totalP90=percentile(this.objectMs,.9)+percentile(this.roadMs,.9)+percentile(this.depthMs,.9);
    const objectStability=Math.sqrt(variance(this.objectCounts));
    return {
      config:this.config,frames:this.frames,laneValid,roadValid,laneJitter,depthJitter,
      totalP90,objectStability,falseRiskHints:this.falseRiskHints,
      warningRate:this.warningFrames/Math.max(1,this.frames),
      avgObjectMs:avg(this.objectMs),avgRoadMs:avg(this.roadMs),avgDepthMs:avg(this.depthMs)
    };
  }
}

function scoreSummary(s,{latencyBudgetMs=130}={}){
  if(!s||s.frames<10)return -Infinity;
  const coverage=(s.laneValid*.42+s.roadValid*.28);
  const laneStable=Math.max(0,1-Math.min(1,s.laneJitter/.10))*.12;
  const depthStable=Math.max(0,1-Math.min(1,s.depthJitter/.16))*.08;
  const latencyPenalty=Math.max(0,(s.totalP90-latencyBudgetMs)/Math.max(1,latencyBudgetMs))*.18;
  const objectPenalty=Math.min(.08,s.objectStability*.012);
  const falseRiskPenalty=Math.min(.15,s.falseRiskHints/Math.max(1,s.frames)*.5);
  return coverage+laneStable+depthStable-latencyPenalty-objectPenalty-falseRiskPenalty;
}

function generateCandidates(base){
  const uniq=new Map();
  const add=c=>{
    const x={
      objectThreshold:+c.objectThreshold.toFixed(2),
      detectEvery:Math.round(c.detectEvery),
      roadEvery:Math.round(c.roadEvery),
      depthEvery:Math.round(c.depthEvery),
      laneStep:Math.round(c.laneStep),
      laneMinWidth:+c.laneMinWidth.toFixed(2),
      depthAlpha:+c.depthAlpha.toFixed(2),
      depthWindow:Math.round(c.depthWindow)
    };
    const k=JSON.stringify(x);if(!uniq.has(k))uniq.set(k,x);
  };
  add(base);
  for(const d of [-1,1])add({...base,detectEvery:Math.max(1,Math.min(12,base.detectEvery+d))});
  for(const d of [-2,2])add({...base,roadEvery:Math.max(2,Math.min(20,base.roadEvery+d))});
  for(const d of [-4,4])add({...base,depthEvery:Math.max(4,Math.min(40,base.depthEvery+d))});
  for(const t of [-.04,.04])add({...base,objectThreshold:Math.max(.10,Math.min(.45,base.objectThreshold+t))});
  add({...base,laneStep:6,laneMinWidth:.07});
  add({...base,laneStep:10,laneMinWidth:.10});
  add({...base,depthAlpha:.24,depthWindow:7});
  add({...base,depthAlpha:.42,depthWindow:3});
  return [...uniq.values()];
}

class AutoTuner{
  constructor({baseConfig,trialFrames=90,minImprovement=.025,latencyBudgetMs=130}){
    this.baseConfig={...baseConfig};this.trialFrames=trialFrames;
    this.minImprovement=minImprovement;this.latencyBudgetMs=latencyBudgetMs;
    this.candidates=generateCandidates(baseConfig);this.index=0;this.current=null;this.results=[];
  }
  start(){this.index=0;this.results=[];this.current=new TrialMetrics(this.candidates[0]);return this.current.config}
  addFrame(metrics){
    if(!this.current)return {done:true};
    this.current.add(metrics);
    if(this.current.frames<this.trialFrames)return {done:false,config:this.current.config};
    const summary=this.current.summary();summary.score=scoreSummary(summary,{latencyBudgetMs:this.latencyBudgetMs});this.results.push(summary);
    this.index++;
    if(this.index>=this.candidates.length){
      const base=this.results.find(r=>JSON.stringify(r.config)===JSON.stringify(this.baseConfig))||this.results[0];
      const best=[...this.results].sort((a,b)=>b.score-a.score)[0];
      const improved=best.score>=base.score+this.minImprovement;
      return {done:true,base,best,improved,selected:improved?best.config:this.baseConfig,results:this.results};
    }
    this.current=new TrialMetrics(this.candidates[this.index]);
    return {done:false,switchConfig:true,config:this.current.config,completed:summary};
  }
}
return {variance,avg,percentile,TrialMetrics,scoreSummary,generateCandidates,AutoTuner};
});