(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.ADASBenchmark=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

class BenchmarkSession{
  constructor(meta={}){
    this.meta={...meta,startedAt:new Date().toISOString()};
    this.frames=0;this.times={object:[],road:[],depth:[]};
    this.counts={objects:0,warnings:0,laneValid:0,roadValid:0,trafficLights:0,trafficSigns:0};
    this.notes=[];
  }
  addFrame({objectMs,roadMs,depthMs,objects=0,warning=false,laneConfidence=0,roadConfidence=0,trafficLights=0,trafficSigns=0}={}){
    this.frames++;
    if(Number.isFinite(objectMs)&&objectMs>0)this.times.object.push(objectMs);
    if(Number.isFinite(roadMs)&&roadMs>0)this.times.road.push(roadMs);
    if(Number.isFinite(depthMs)&&depthMs>0)this.times.depth.push(depthMs);
    this.counts.objects+=objects;
    this.counts.warnings+=warning?1:0;
    this.counts.laneValid+=laneConfidence>.35?1:0;
    this.counts.roadValid+=roadConfidence>.35?1:0;
    this.counts.trafficLights+=trafficLights;
    this.counts.trafficSigns+=trafficSigns;
  }
  summary(){
    const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:null;
    const pct=(a,b)=>b?100*a/b:0;
    return {
      meta:this.meta,
      frames:this.frames,
      avgObjectMs:avg(this.times.object),
      avgRoadMs:avg(this.times.road),
      avgDepthMs:avg(this.times.depth),
      avgObjectsPerFrame:this.frames?this.counts.objects/this.frames:0,
      warningFramePct:pct(this.counts.warnings,this.frames),
      laneValidPct:pct(this.counts.laneValid,this.frames),
      roadValidPct:pct(this.counts.roadValid,this.frames),
      trafficLights:this.counts.trafficLights,
      trafficSigns:this.counts.trafficSigns,
      notes:this.notes
    };
  }
}
return {BenchmarkSession};
});