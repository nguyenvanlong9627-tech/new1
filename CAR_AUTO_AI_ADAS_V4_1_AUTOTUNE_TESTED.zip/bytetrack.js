(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.ByteTrackJS=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const iou=(a,b)=>{
  const x1=Math.max(a[0],b[0]),y1=Math.max(a[1],b[1]);
  const x2=Math.min(a[0]+a[2],b[0]+b[2]),y2=Math.min(a[1]+a[3],b[1]+b[3]);
  const inter=Math.max(0,x2-x1)*Math.max(0,y2-y1);
  return inter/(a[2]*a[3]+b[2]*b[3]-inter+1e-9);
};
function greedyAssign(tracks,dets,threshold){
  const pairs=[];
  for(let ti=0;ti<tracks.length;ti++)for(let di=0;di<dets.length;di++){
    if(tracks[ti].class!==dets[di].class)continue;
    const score=iou(tracks[ti].bbox,dets[di].bbox);
    if(score>=threshold)pairs.push({ti,di,score});
  }
  pairs.sort((a,b)=>b.score-a.score);
  const usedT=new Set(),usedD=new Set(),matches=[];
  for(const p of pairs){
    if(usedT.has(p.ti)||usedD.has(p.di))continue;
    usedT.add(p.ti);usedD.add(p.di);matches.push(p);
  }
  return {
    matches,
    unmatchedTracks:tracks.map((_,i)=>i).filter(i=>!usedT.has(i)),
    unmatchedDets:dets.map((_,i)=>i).filter(i=>!usedD.has(i))
  };
}
class Track{
  constructor(det,id){
    this.id=id;this.class=det.class;this.bbox=det.bbox.slice();this.score=det.score;
    this.state='tracked';this.age=1;this.timeSinceUpdate=0;this.hits=1;
    this.velocity=[0,0,0,0];this.prevBox=null;
  }
  predict(){
    this.prevBox=this.bbox.slice();
    this.bbox=[
      this.bbox[0]+this.velocity[0],this.bbox[1]+this.velocity[1],
      Math.max(2,this.bbox[2]+this.velocity[2]),Math.max(2,this.bbox[3]+this.velocity[3])
    ];
    this.age++;this.timeSinceUpdate++;
  }
  update(det){
    const old=this.prevBox||this.bbox,alpha=.65;
    const v=[det.bbox[0]-old[0],det.bbox[1]-old[1],det.bbox[2]-old[2],det.bbox[3]-old[3]];
    this.velocity=this.velocity.map((x,i)=>x*.45+v[i]*.55);
    this.bbox=this.bbox.map((x,i)=>x*(1-alpha)+det.bbox[i]*alpha);
    this.score=det.score;this.state='tracked';this.timeSinceUpdate=0;this.hits++;
  }
  markLost(){this.state='lost'}
}
class ByteTracker{
  constructor(opts={}){
    this.high=opts.highThreshold??0.55;this.low=opts.lowThreshold??0.10;
    this.match=opts.matchThreshold??0.30;this.lowMatch=opts.lowMatchThreshold??0.20;
    this.maxLost=opts.maxLost??18;this.minHits=opts.minHits??2;this.nextId=1;this.tracks=[];
  }
  update(detections){
    for(const t of this.tracks)t.predict();
    const high=detections.filter(d=>d.score>=this.high);
    const low=detections.filter(d=>d.score>=this.low&&d.score<this.high);
    const active=this.tracks.filter(t=>t.timeSinceUpdate<=this.maxLost);
    const a1=greedyAssign(active,high,this.match);
    for(const m of a1.matches)active[m.ti].update(high[m.di]);
    const unmatchedActive=a1.unmatchedTracks.map(i=>active[i]);
    const a2=greedyAssign(unmatchedActive,low,this.lowMatch);
    for(const m of a2.matches)unmatchedActive[m.ti].update(low[m.di]);
    for(const i of a2.unmatchedTracks)unmatchedActive[i].markLost();
    for(const di of a1.unmatchedDets)this.tracks.push(new Track(high[di],this.nextId++));
    this.tracks=this.tracks.filter(t=>t.timeSinceUpdate<=this.maxLost);
    return this.tracks.filter(t=>t.state==='tracked'&&t.hits>=this.minHits)
      .map(t=>({id:t.id,class:t.class,bbox:t.bbox.slice(),prevBox:t.prevBox?t.prevBox.slice():null,score:t.score,age:t.timeSinceUpdate,hits:t.hits}));
  }
}
return {ByteTracker,Track,greedyAssign,iou};
});