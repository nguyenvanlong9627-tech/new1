(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.ADASCore=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;

  function iou(a,b){
    const ax2=a[0]+a[2], ay2=a[1]+a[3], bx2=b[0]+b[2], by2=b[1]+b[3];
    const x1=Math.max(a[0],b[0]), y1=Math.max(a[1],b[1]), x2=Math.min(ax2,bx2), y2=Math.min(ay2,by2);
    const inter=Math.max(0,x2-x1)*Math.max(0,y2-y1);
    return inter/(a[2]*a[3]+b[2]*b[3]-inter+1e-9);
  }

  function fitLine(points){
    if(!points||points.length<4)return null;
    let sx=0,sy=0,sxy=0,syy=0;
    for(const p of points){sx+=p[0];sy+=p[1];sxy+=p[0]*p[1];syy+=p[1]*p[1]}
    const n=points.length, den=n*syy-sy*sy;
    if(Math.abs(den)<1e-9)return null;
    const a=(n*sxy-sy*sx)/den, b=(sx-a*sy)/n;
    return {a,b,yTop:Math.min(...points.map(p=>p[1])),yBot:Math.max(...points.map(p=>p[1]))};
  }

  function xAtY(line,y){
    if(!line)return null;
    const dy=line.y2-line.y1;
    return Math.abs(dy)<1?line.x2:line.x1+(line.x2-line.x1)*(y-line.y1)/dy;
  }

  function adaptiveStride(baseStride,fps,target=24){
    baseStride=Math.max(1,Math.round(baseStride));
    if(!Number.isFinite(fps)||fps<=0)return baseStride;
    if(fps<target*.55)return Math.min(12,baseStride+4);
    if(fps<target*.75)return Math.min(12,baseStride+2);
    if(fps>target*1.45)return Math.max(1,baseStride-1);
    return baseStride;
  }

  function distanceFusion({boxHeightPx,footY,horizonY,focalPx,objectHeight,cameraHeight}){
    if(boxHeightPx<3||focalPx<=0)return null;
    const sizeDist=objectHeight*focalPx/boxHeightPx;
    let groundDist=null;
    const denom=footY-horizonY;
    if(denom>3)groundDist=cameraHeight*focalPx/denom;
    let estimate=sizeDist, confidence=.45;
    if(groundDist&&groundDist>0){
      const ratio=Math.max(sizeDist,groundDist)/Math.max(.1,Math.min(sizeDist,groundDist));
      if(ratio<2.2){estimate=sizeDist*.55+groundDist*.45;confidence=.68}
      else {estimate=Math.min(sizeDist,groundDist)*.65+Math.max(sizeDist,groundDist)*.35;confidence=.40}
    }
    estimate=clamp(estimate,1,180);
    const relErr=confidence>.6?.22:.34;
    return {estimate,low:Math.max(0.5,estimate*(1-relErr)),high:estimate*(1+relErr),confidence};
  }

  function sceneLight(meanLuma){
    if(meanLuma<35)return {state:'VERY DARK',confidence:.9};
    if(meanLuma<65)return {state:'LOW LIGHT',confidence:.75};
    if(meanLuma>215)return {state:'OVEREXPOSED',confidence:.7};
    return {state:'NORMAL',confidence:.8};
  }

  function obstructionMetric({variance,edgeDensity}){
    const blocked=variance<70&&edgeDensity<0.015;
    const suspicious=variance<130&&edgeDensity<0.025;
    return blocked?{state:'CAMERA BLOCKED',confidence:.85}:suspicious?{state:'CAMERA LOW DETAIL',confidence:.6}:{state:'CLEAR',confidence:.7};
  }

  function curvatureFromLines(left,right,h){
    if(!left||!right)return null;
    const yA=h*.58,yB=h*.78,yC=h*.95;
    const cA=(xAtY(left,yA)+xAtY(right,yA))/2;
    const cB=(xAtY(left,yB)+xAtY(right,yB))/2;
    const cC=(xAtY(left,yC)+xAtY(right,yC))/2;
    const bend=cA-2*cB+cC;
    if(Math.abs(bend)<4)return {label:'STRAIGHT',score:bend};
    return {label:bend>0?'RIGHT':'LEFT',score:bend};
  }

  function riskDecision({lead,laneDeparture,cutIn,speedKmh,laneConfidence}){
    if(lead && lead.distance && lead.distance.confidence>=.35){
      const d=lead.distance.estimate;
      if(lead.ttc&&lead.ttc<2.0)return {level:'danger',text:'⚠ FORWARD COLLISION'};
      if(d<Math.max(5,speedKmh*.18))return {level:'warn',text:'⚠ SAFE DISTANCE'};
    }
    if(cutIn)return {level:'warn',text:'⚠ CUT-IN VEHICLE'};
    if(laneDeparture&&laneConfidence>.45)return {level:'warn',text:'⚠ LANE DEPARTURE'};
    return {level:'none',text:''};
  }


  function pointInRect(x,y,r){
    return x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;
  }

  function detectionInNoScanZone(bbox,zones,videoW,videoH){
    if(!bbox||!zones||!zones.length||!videoW||!videoH)return false;
    const cx=(bbox[0]+bbox[2]/2)/videoW, cy=(bbox[1]+bbox[3]/2)/videoH;
    return zones.some(r=>pointInRect(cx,cy,r));
  }

  function likelyOncoming(samples,opts={}){
    if(!samples||samples.length<3)return false;
    const first=samples[0], last=samples[samples.length-1];
    const dt=Math.max(.08,(last.time-first.time)/1000);
    const growth=(last.h-first.h)/Math.max(.01,first.h)/dt;
    const vertical=(last.footY-first.footY)/dt;
    const vpX=opts.vanishingX==null?.5:opts.vanishingX;
    const firstDx=Math.abs(first.cx-vpX), lastDx=Math.abs(last.cx-vpX);
    const lateralDivergence=(lastDx-firstDx)/dt;
    // Strong apparent approach + movement down-frame + divergence from vanishing point.
    // Kept conservative to avoid suppressing a same-direction lead vehicle.
    return growth>.35 && vertical>.10 && lateralDivergence>.015 && !last.inLane;
  }

  function detectCutIn(prevX,currentX,inLanePrev,inLaneNow,boxW){
    if(inLanePrev||!inLaneNow)return false;
    return Math.abs(currentX-prevX)>Math.max(8,boxW*.08);
  }

  return {clamp,lerp,iou,fitLine,xAtY,adaptiveStride,distanceFusion,sceneLight,obstructionMetric,curvatureFromLines,riskDecision,detectCutIn,pointInRect,detectionInNoScanZone,likelyOncoming};
});