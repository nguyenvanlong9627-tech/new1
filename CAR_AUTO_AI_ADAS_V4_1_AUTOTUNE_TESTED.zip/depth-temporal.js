(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.DepthTemporalAI=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

class TemporalDepthSmoother{
  constructor({alpha=.35,medianWindow=5,maxJump=.28}={}){
    this.alpha=alpha;this.medianWindow=medianWindow;this.maxJump=maxJump;
    this.history=new Map();
  }
  update(id,value){
    if(value==null||!Number.isFinite(value))return null;
    const arr=this.history.get(id)||[];
    arr.push(value);while(arr.length>this.medianWindow)arr.shift();
    const sorted=[...arr].sort((a,b)=>a-b);
    const med=sorted[Math.floor(sorted.length/2)];
    let out=med;
    if(arr._ema!=null){
      const delta=med-arr._ema;
      const bounded=Math.abs(delta)>this.maxJump?arr._ema+Math.sign(delta)*this.maxJump:med;
      out=arr._ema*(1-this.alpha)+bounded*this.alpha;
    }
    arr._ema=out;this.history.set(id,arr);return out;
  }
  remove(id){this.history.delete(id)}
  clear(){this.history.clear()}
}
return {TemporalDepthSmoother};
});