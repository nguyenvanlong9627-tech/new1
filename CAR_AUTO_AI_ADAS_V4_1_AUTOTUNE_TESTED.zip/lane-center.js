(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.LaneCenterAI=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

function extractCenterline(mask,{minYRatio=.45,maxYRatio=.98,step=8,minWidthRatio=.08}={}){
  if(!mask||!mask.data||!mask.width||!mask.height)return {points:[],confidence:0};
  const pts=[],w=mask.width,h=mask.height;
  for(let y=Math.floor(h*minYRatio);y<Math.floor(h*maxYRatio);y+=step){
    let xs=[];
    for(let x=0;x<w;x++)if(mask.data[y*w+x])xs.push(x);
    if(xs.length<2)continue;
    const left=xs[0],right=xs[xs.length-1],width=right-left;
    if(width<w*minWidthRatio)continue;
    pts.push({x:(left+right)/2,y,left,right,width});
  }
  if(!pts.length)return {points:[],confidence:0};
  // weighted smoothing, favor near-field rows
  const smoothed=pts.map((p,i)=>{
    let sx=0,sw=0;
    for(let j=Math.max(0,i-2);j<=Math.min(pts.length-1,i+2);j++){
      const wt=1/(1+Math.abs(i-j));
      sx+=pts[j].x*wt;sw+=wt;
    }
    return {...p,x:sx/sw};
  });
  const coverage=smoothed.length/Math.max(1,Math.ceil((h*(maxYRatio-minYRatio))/step));
  const widthStability=(()=>{
    const arr=smoothed.map(p=>p.width),avg=arr.reduce((a,b)=>a+b,0)/arr.length;
    const mad=arr.reduce((a,b)=>a+Math.abs(b-avg),0)/arr.length;
    return Math.max(0,1-mad/Math.max(1,avg));
  })();
  return {points:smoothed,confidence:Math.max(0,Math.min(1,coverage*.65+widthStability*.35))};
}

function normalizedCenterline(mask,opts){
  const r=extractCenterline(mask,opts);
  return {confidence:r.confidence,points:r.points.map(p=>({x:p.x/mask.width,y:p.y/mask.height,left:p.left/mask.width,right:p.right/mask.width}))};
}

function lateralOffset(normLine,nearY=.90){
  if(!normLine?.points?.length)return null;
  let best=normLine.points[0];
  for(const p of normLine.points)if(Math.abs(p.y-nearY)<Math.abs(best.y-nearY))best=p;
  return {offset:best.x-.5, laneWidth:best.right-best.left, y:best.y};
}

return {extractCenterline,normalizedCenterline,lateralOffset};
});