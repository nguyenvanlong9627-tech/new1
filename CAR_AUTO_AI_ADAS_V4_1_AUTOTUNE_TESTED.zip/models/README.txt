Đặt yolop-640-640.onnx và depth-anything-v2-small-q4f16.onnx vào đây.
