const assert=require('assert');
const A=require('../autotune.js');

const base={objectThreshold:.18,detectEvery:4,roadEvery:5,depthEvery:12,laneStep:8,laneMinWidth:.08,depthAlpha:.32,depthWindow:5};
const cs=A.generateCandidates(base);
assert(cs.length>=8);
assert(JSON.stringify(cs[0])===JSON.stringify(base));

const good=new A.TrialMetrics(base);
for(let i=0;i<100;i++)good.add({laneConfidence:.8,roadConfidence:.9,laneOffset:.01+(i%2)*.002,depth:.5+(i%2)*.003,objectMs:15,roadMs:30,depthMs:40,objects:4,warning:false});
const bad=new A.TrialMetrics(base);
for(let i=0;i<100;i++)bad.add({laneConfidence:.1,roadConfidence:.2,laneOffset:(i%2)*.2,depth:(i%2)*.7,objectMs:70,roadMs:100,depthMs:140,objects:(i%2)*10,warning:true,falseRiskHint:true});
assert(A.scoreSummary(good.summary())>A.scoreSummary(bad.summary()));

const tuner=new A.AutoTuner({baseConfig:base,trialFrames:10,minImprovement:.005});
let cfg=tuner.start(),res=null;
for(let ci=0;ci<tuner.candidates.length;ci++){
  for(let f=0;f<10;f++){
    const quality=ci===2;
    res=tuner.addFrame({laneConfidence:quality?.9:.65,roadConfidence:quality?.9:.7,laneOffset:quality?.005:.04,depth:quality?.5:.55+(f%2)*.03,objectMs:quality?10:25,roadMs:quality?20:35,depthMs:quality?25:50,objects:4});
  }
}
assert(res.done);
assert(res.best.score>=res.base.score);
assert(res.improved===true);
console.log('V4.1 AutoTune tests passed');