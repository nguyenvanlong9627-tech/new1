const assert=require('assert');
const C=require('../core.js');
let passed=0;
function test(name,fn){try{fn();passed++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e.message);process.exitCode=1}}
function near(a,b,e=1e-6){assert(Math.abs(a-b)<e,`${a} !~= ${b}`)}

test('IoU identical',()=>near(C.iou([0,0,10,10],[0,0,10,10]),1));
test('IoU separated',()=>near(C.iou([0,0,10,10],[20,20,5,5]),0));
test('Line fitting',()=>{const l=C.fitLine([[1,1],[2,2],[3,3],[4,4],[5,5]]);assert(l);near(l.a,1)});
test('Line fitting rejects too few points',()=>assert.equal(C.fitLine([[1,1],[2,2]]),null));
test('xAtY interpolation',()=>near(C.xAtY({x1:0,y1:0,x2:10,y2:10},5),5));
test('Adaptive stride increases on low FPS',()=>assert.equal(C.adaptiveStride(4,8,24),8));
test('Adaptive stride decreases on high FPS',()=>assert.equal(C.adaptiveStride(4,40,24),3));
test('Adaptive stride remains base near target',()=>assert.equal(C.adaptiveStride(4,24,24),4));
test('Distance fusion returns uncertainty',()=>{const d=C.distanceFusion({boxHeightPx:100,footY:500,horizonY:300,focalPx:800,objectHeight:1.5,cameraHeight:1.35});assert(d);assert(d.low<d.estimate&&d.high>d.estimate);assert(d.confidence>0)});
test('Distance fusion rejects tiny boxes',()=>assert.equal(C.distanceFusion({boxHeightPx:1,footY:500,horizonY:300,focalPx:800,objectHeight:1.5,cameraHeight:1.35}),null));
test('Very dark scene',()=>assert.equal(C.sceneLight(20).state,'VERY DARK'));
test('Low light scene',()=>assert.equal(C.sceneLight(50).state,'LOW LIGHT'));
test('Normal light scene',()=>assert.equal(C.sceneLight(100).state,'NORMAL'));
test('Overexposed scene',()=>assert.equal(C.sceneLight(230).state,'OVEREXPOSED'));
test('Camera blocked metric',()=>assert.equal(C.obstructionMetric({variance:20,edgeDensity:.001}).state,'CAMERA BLOCKED'));
test('Camera clear metric',()=>assert.equal(C.obstructionMetric({variance:500,edgeDensity:.1}).state,'CLEAR'));
test('Cut-in detects outside-to-inside transition',()=>assert.equal(C.detectCutIn(100,130,false,true,100),true));
test('Cut-in ignores already-in-lane object',()=>assert.equal(C.detectCutIn(100,130,true,true,100),false));
test('Collision risk outranks others',()=>{const r=C.riskDecision({lead:{distance:{estimate:5,confidence:.8},ttc:1.5},laneDeparture:true,cutIn:true,speedKmh:50,laneConfidence:.9});assert.equal(r.level,'danger');assert(r.text.includes('COLLISION'))});
test('Safe distance warning',()=>{const r=C.riskDecision({lead:{distance:{estimate:6,confidence:.8},ttc:null},laneDeparture:false,cutIn:false,speedKmh:60,laneConfidence:.9});assert.equal(r.level,'warn');assert(r.text.includes('SAFE DISTANCE'))});
test('Lane departure requires lane confidence',()=>{const r=C.riskDecision({lead:null,laneDeparture:true,cutIn:false,speedKmh:50,laneConfidence:.2});assert.equal(r.level,'none')});
test('Cut-in warning',()=>{const r=C.riskDecision({lead:null,laneDeparture:false,cutIn:true,speedKmh:50,laneConfidence:.9});assert(r.text.includes('CUT-IN'))});
test('Curvature straight',()=>{const l={x1:100,y1:50,x2:120,y2:100},r={x1:200,y1:50,x2:220,y2:100};const c=C.curvatureFromLines(l,r,100);assert(c)});
console.log(`\n${passed} core tests passed`);

assert.equal(C.pointInRect(.5,.5,{x:.2,y:.2,w:.5,h:.5}),true);
assert.equal(C.pointInRect(.9,.9,{x:.2,y:.2,w:.5,h:.5}),false);
assert.equal(C.detectionInNoScanZone([40,40,20,20],[{x:.4,y:.4,w:.2,h:.2}],100,100),true);
assert.equal(C.detectionInNoScanZone([0,0,10,10],[{x:.4,y:.4,w:.2,h:.2}],100,100),false);
const oncomingSamples=[
 {time:0,h:.08,footY:.55,cx:.48,inLane:false},
 {time:500,h:.11,footY:.63,cx:.53,inLane:false},
 {time:1000,h:.16,footY:.74,cx:.59,inLane:false}
];
assert.equal(C.likelyOncoming(oncomingSamples,{vanishingX:.5}),true);
const leadSamples=[
 {time:0,h:.08,footY:.55,cx:.50,inLane:true},
 {time:500,h:.09,footY:.58,cx:.50,inLane:true},
 {time:1000,h:.10,footY:.61,cx:.50,inLane:true}
];
assert.equal(C.likelyOncoming(leadSamples,{vanishingX:.5}),false);
console.log('Filtering tests passed');
