const assert=require('assert');
const B=require('../bytetrack.js');
const A=require('../ai-engine.js');

const tr=new B.ByteTracker({highThreshold:.5,lowThreshold:.1,matchThreshold:.2,lowMatchThreshold:.1,maxLost:3,minHits:1});
let out=tr.update([{class:'car',score:.9,bbox:[10,10,50,30]}]);
assert.equal(out.length,1);const id=out[0].id;
out=tr.update([{class:'car',score:.8,bbox:[12,11,50,30]}]);
assert.equal(out.length,1);assert.equal(out[0].id,id);
out=tr.update([{class:'car',score:.2,bbox:[14,12,50,30]}]);
assert.equal(out.length,1);assert.equal(out[0].id,id);
out=tr.update([{class:'person',score:.9,bbox:[200,50,20,50]}]);
assert(out.some(x=>x.class==='person'));
assert(B.iou([0,0,10,10],[0,0,10,10])>.99);
assert.equal(A.hasWebGPU(),false);
console.log('V3 ByteTrack/AI utility tests passed');