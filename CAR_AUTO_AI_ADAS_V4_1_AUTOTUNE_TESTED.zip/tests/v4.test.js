const assert=require('assert');
const L=require('../lane-center.js');
const D=require('../depth-temporal.js');
const T=require('../traffic-ai.js');
const B=require('../benchmark.js');

const w=20,h=20,data=new Uint8Array(w*h);
for(let y=8;y<20;y++)for(let x=5;x<=14;x++)data[y*w+x]=1;
const line=L.normalizedCenterline({data,width:w,height:h},{minYRatio:.4,maxYRatio:1,step:2,minWidthRatio:.1});
assert(line.points.length>0);
assert(line.confidence>0);
const off=L.lateralOffset(line,.9);
assert(off && Math.abs(off.offset)<.05);

const s=new D.TemporalDepthSmoother({alpha:.5,medianWindow:3,maxJump:.2});
const a=s.update(1,.5);const b=s.update(1,.52);const c=s.update(1,.95);
assert(a!==null&&b!==null&&c!==null);
assert(c<.8); // jump limited/smoothed

const filtered=T.filterBaseTrafficDetections([{class:'traffic light'},{class:'car'},{class:'stop sign'}]);
assert.equal(filtered.length,2);

const bm=new B.BenchmarkSession({profile:'test'});
bm.addFrame({objectMs:10,roadMs:20,depthMs:30,objects:3,warning:true,laneConfidence:.8,roadConfidence:.9,trafficLights:1,trafficSigns:1});
const sum=bm.summary();
assert.equal(sum.frames,1);
assert.equal(sum.trafficLights,1);
assert(sum.laneValidPct===100);
console.log('V4 lane/depth/traffic/benchmark tests passed');