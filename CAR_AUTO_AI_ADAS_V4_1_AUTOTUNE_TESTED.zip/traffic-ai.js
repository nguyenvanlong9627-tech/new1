(function(root,factory){
const api=factory();
if(typeof module==='object'&&module.exports)module.exports=api;
root.TrafficAI=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

const DEFAULT_CLASSES=['traffic_light_red','traffic_light_yellow','traffic_light_green','stop','yield','speed_limit','no_entry','turn_left','turn_right','warning'];

function classifyTrafficLightColor(video,bbox){
  try{
    const [x,y,w,h]=bbox;
    if(w<3||h<3)return {state:'unknown',confidence:0};
    const c=document.createElement('canvas'),cw=24,ch=48;c.width=cw;c.height=ch;
    const ctx=c.getContext('2d',{willReadFrequently:true});
    ctx.drawImage(video,x,y,w,h,0,0,cw,ch);
    const d=ctx.getImageData(0,0,cw,ch).data;
    let top=[0,0,0],mid=[0,0,0],bot=[0,0,0],tc=0,mc=0,bc=0;
    for(let yy=0;yy<ch;yy++)for(let xx=0;xx<cw;xx++){
      const i=(yy*cw+xx)*4,r=d[i],g=d[i+1],b=d[i+2];
      if(yy<ch/3){top[0]+=r;top[1]+=g;top[2]+=b;tc++}
      else if(yy<2*ch/3){mid[0]+=r;mid[1]+=g;mid[2]+=b;mc++}
      else{bot[0]+=r;bot[1]+=g;bot[2]+=b;bc++}
    }
    const avg=(a,n)=>a.map(v=>v/Math.max(1,n));
    top=avg(top,tc);mid=avg(mid,mc);bot=avg(bot,bc);
    const redScore=top[0]-Math.max(top[1],top[2]);
    const yellowScore=(mid[0]+mid[1])/2-mid[2];
    const greenScore=bot[1]-Math.max(bot[0],bot[2]);
    const scores={red:redScore,yellow:yellowScore,green:greenScore};
    const state=Object.entries(scores).sort((a,b)=>b[1]-a[1])[0][0];
    const best=scores[state],confidence=Math.max(0,Math.min(1,(best-8)/80));
    return confidence>.15?{state,confidence}:{state:'unknown',confidence};
  }catch(e){return {state:'unknown',confidence:0}}
}

class OptionalTrafficSignONNX{
  constructor({modelUrl='models/traffic-sign-vn.onnx',classes=DEFAULT_CLASSES}={}){
    this.modelUrl=modelUrl;this.classes=classes;this.session=null;this.provider='—';this.error=null;
  }
  async init(){
    if(typeof ort==='undefined')throw new Error('ONNX Runtime Web unavailable');
    const providers=(typeof navigator!=='undefined'&&navigator.gpu)?['webgpu','wasm']:['wasm'];
    try{
      this.session=await ort.InferenceSession.create(this.modelUrl,{executionProviders:providers,graphOptimizationLevel:'all'});
      this.provider=providers[0];return true;
    }catch(e){
      if(providers[0]==='webgpu'){
        try{
          this.session=await ort.InferenceSession.create(this.modelUrl,{executionProviders:['wasm'],graphOptimizationLevel:'all'});
          this.provider='wasm';return true;
        }catch(e2){this.error=e2;throw e2}
      }
      this.error=e;throw e;
    }
  }
  async infer(){ return []; } // adapter ready; concrete decoder depends on chosen Vietnamese sign model export.
}

function filterBaseTrafficDetections(dets){
  return dets.filter(d=>d.class==='traffic light'||d.class==='stop sign');
}

return {DEFAULT_CLASSES,classifyTrafficLightColor,OptionalTrafficSignONNX,filterBaseTrafficDetections};
});